import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

export default function Home() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen pt-20 px-4">
        <h1 className="text-3xl font-bold text-center text-blue-600">Bem-vindo ao ZappTurbo</h1>
        <p className="text-center mt-4">Automatize seu atendimento com inteligência!</p>
      </main>
      <Footer />
    </>
  )
}