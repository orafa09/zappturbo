export default function Footer() {
  return (
    <footer className="bg-gray-100 text-center py-6 mt-12">
      <div className="text-sm text-gray-600">
        © {new Date().getFullYear()} ZappTurbo. Todos os direitos reservados.
      </div>
      <div className="mt-2 space-x-4 text-blue-500">
        <a href="/termos-de-uso">Termos de Uso</a>
        <a href="/politica-de-privacidade">Política de Privacidade</a>
      </div>
    </footer>
  );
}