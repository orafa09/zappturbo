import Link from 'next/link';

export default function Navbar() {
  return (
    <nav className="bg-white shadow-md fixed w-full z-50">
      <div className="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center">
        <h1 className="text-xl font-bold text-blue-600">ZappTurbo</h1>
        <ul className="flex space-x-6">
          <li><Link href="/">Home</Link></li>
          <li><Link href="/servicos">Serviços</Link></li>
          <li><Link href="/precos">Preços</Link></li>
          <li><Link href="/contato">Contato</Link></li>
        </ul>
        <div className="space-x-2">
          <Link href="/login" className="text-blue-600 font-medium">Login</Link>
          <Link href="/cadastro" className="bg-blue-600 text-white px-4 py-1 rounded hover:bg-blue-700">Comece Grátis</Link>
        </div>
      </div>
    </nav>
  );
}